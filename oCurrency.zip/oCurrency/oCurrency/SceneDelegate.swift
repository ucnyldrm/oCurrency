//
//  SceneDelegate.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 16.03.2023.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    
    var window: UIWindow?
    
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {

        guard let _ = (scene as? UIWindowScene) else { return }


        if UserDefaults.standard.bool(forKey: "Switch") {

            window?.overrideUserInterfaceStyle = .dark
            
        } else {
            
            window?.overrideUserInterfaceStyle = .light
            
        }
        
    }
        
}
