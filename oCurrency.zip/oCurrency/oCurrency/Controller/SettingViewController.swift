//
//  SettingViewController.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 6.06.23.
//

import UIKit


class SettingViewController: UITableViewController {
    
    @IBOutlet weak var modeLabel : UILabel!
    @IBOutlet weak var modeSwitch : UISwitch!
    @IBOutlet weak var tableview : UITableView!
    
    let defaults = UserDefaults.standard
    let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene


    
    override func viewDidLoad() {

        view.backgroundColor = UIColor(named: "lead")
        
        if let tableView = tableview {
            
            deviceRowHeight(phone: 60, pad: 120, tableview: tableView)
            
        }
    
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    
        if let modeSwitch = modeSwitch {
            
            modeSwitch.isOn = defaults.bool(forKey: "Switch")
            isOn(isOn: modeSwitch.isOn)
            
        }
    }

    
    @IBAction func switchValueChanged(_ sender: UISwitch) {

        defaults.set(sender.isOn, forKey: "Switch")
        isOn(isOn: sender.isOn)
        
    }
    
    func isOn(isOn : Bool) {
        
        let window = windowScene?.windows.first
        window?.overrideUserInterfaceStyle = isOn ? .dark : .light
        modeLabel.text = isOn ? "Dark Mode" : "Light Mode"
        modeLabel.textColor = isOn ? .white : .black
         
      }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        (view as! UITableViewHeaderFooterView).textLabel?.font = UIFont(name: "Helvetica Neue Medium", size: 30)
        (view as! UITableViewHeaderFooterView).textLabel?.text = "Settings"
        (view as! UITableViewHeaderFooterView).textLabel?.textColor = .label
        
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 90
    }
    
}
