//
//  ChartsViewController.swift
//  oCurrency
//
//  Created by Can Yıldırım on 29.11.23.
//

import UIKit
import Charts
import TinyConstraints
import SkeletonView

class ChartsViewController: UIViewController, ChartViewDelegate {
    
    @IBOutlet weak var popUpButtonI: UIButton!
    @IBOutlet weak var popUpButtonII: UIButton!
    @IBOutlet weak var currencyLabel: UILabel!
    @IBOutlet weak var highLabel: UILabel!
    @IBOutlet weak var lowLabel: UILabel!
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var activityIndicator : UIActivityIndicatorView!
    
    
    var lineChart = LineChartView()
    let dateFormatter = DateFormatter()
    var entries = [ChartDataEntry]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityIndicator.startAnimating()

        lineChart.delegate = self
        segmentedControl.addTarget(self, action: #selector(setHistoricalRates), for: .valueChanged)
        setPopUpButton()
        defaultHistoricalDates()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        stopSkeleton(delay: 1)
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        view.addSubview(lineChart)
        setStackPosition()

        lineChart.centerInSuperview()
        lineChart.width(to: view)
        lineChart.heightToWidth(of: view) 
        lineChart.rightAxis.enabled = false
        
        let yAxis = lineChart.leftAxis
        yAxis.setLabelCount(6, force: false)
        yAxis.labelPosition = .insideChart
        yAxis.drawAxisLineEnabled = false
        
        let xAxis = lineChart.xAxis
        xAxis.enabled = false

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        lineChart.isSkeletonable = true
        lineChart.showAnimatedGradientSkeleton(usingGradient: .init(baseColor: UIColor.init(named: "lead")!), animation: nil, transition: .crossDissolve(0.25))
        
    }
    
    @objc func setHistoricalRates() {
        
        lineChart.showAnimatedGradientSkeleton(usingGradient: .init(baseColor: UIColor.init(named: "lead")!), animation: nil, transition: .crossDissolve(0.25))
        
        entries = []
        
        var year = 0
        var month = 0
        var day = -7
        
        if segmentedControl.selectedSegmentIndex == 0 {
            
            entries = []
            year = 0
            month = 0
            day = -7
            lineChart.animate(xAxisDuration: 1)
            stopSkeleton(delay: 1)
            activityIndicator.startAnimating()


        }
        
        if segmentedControl.selectedSegmentIndex == 1 {
            
            entries = []
            year = 0
            month = -1
            day = 0
            lineChart.animate(xAxisDuration: 2)
            stopSkeleton(delay: 2)
            activityIndicator.startAnimating()

            
        }
        
        if segmentedControl.selectedSegmentIndex == 2 {
            
            entries = []
            year = -1
            month = 0
            day = 0
            stopSkeleton(delay: 5)
            activityIndicator.startAnimating()

            
        }
        
        if segmentedControl.selectedSegmentIndex == 3 {

            entries = []

            year = -3
            month = 0
            day = 0
            stopSkeleton(delay: 7)
            activityIndicator.startAnimating()

            
        }

        for date in Date.dates(from: Date().dateFinder(year: year, month: month, day: day), to: Date()) {

            if let popUpButtonI = popUpButtonI.titleLabel?.text {

                OCClient.historical(date: dateFormatter.string(from: date), base: popUpButtonI) { data, error in

                    if let data = data {

                        self.setLineChartData()
                        
                        if let popUpButton = self.popUpButtonII.titleLabel?.text {

                            switch popUpButton {

                            case "USD" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.usd))
                            case "EUR" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.eur))
                            case "GBP" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.gbp))
                            case "CHF" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.chf))
                            case "CNY" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.cny))
                            case "JPY" : self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.jpy))

                            default : break

                            }

                        }

                    }

                }

            }

        }
 
    }
    
    func setPopUpButton() {
                
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        let date = dateFormatter.string(from: Date())
        
        let optionClosure = {(action: UIAction) in
            
            OCClient.historical(date: date, base: action.title) { data, error in
                if let data = data {
                    
                    if let popUpButton = self.popUpButtonII.titleLabel?.text {
                        
                        switch popUpButton {
                            
                        case "USD" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.usd) USD"
                            self.setHistoricalRates()

                        case "EUR" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.eur) EUR"
                            self.setHistoricalRates()

                        case "GBP" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.gbp) GBP"

                        case "CHF" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.chf) CHF"
                            self.setHistoricalRates()

                        case "CNY" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.cny) CNY"
                            self.setHistoricalRates()

                        case "JPY" : self.currencyLabel.text = "1 \(action.title) = \(data.rates.jpy) JPY"
                            self.setHistoricalRates()
                            
                        default : break
                            
                        }
                    }
                }
            }
        }
        
        OCClient.symbols { data, error in
            
            if let data = data {
                
                let sortedSymbols = data.symbols.sorted(by: {$0 < $1})
                
                let actions : [UIAction] = sortedSymbols.map {
                    
                    let action = UIAction(title: $0.key, subtitle: $0.value, state: .on, handler: optionClosure)
                    
                    return action
                }

                self.popUpButtonI.menu = UIMenu(children: actions)
                
            }
            
        }
        
        let optionClosureII = {(action: UIAction) in
            
            if let popUpButton = self.popUpButtonI.titleLabel?.text {
                
                OCClient.historical(date: date, base: popUpButton) { data, error in
                    
                    if let data = data {

                        switch action.title {
                            
                        case "USD" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.usd) USD"
                            self.setHistoricalRates()
                            
                        case "EUR" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.eur) EUR"
                            self.setHistoricalRates()
                            
                        case "GBP" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.gbp) GBP"
                            self.setHistoricalRates()
                            
                        case "CHF" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.chf) CHF"
                            self.setHistoricalRates()

                        case "CNY" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.cny) CNY"
                            self.setHistoricalRates()
                            
                        case "JPY" : self.currencyLabel.text = "1 \(popUpButton) = \(data.rates.jpy) JPY"
                            self.setHistoricalRates()

                        default: break
                            
                        }
                    }
                }
            }
        }
        
        popUpButtonII.menu = UIMenu(children: [
                    
                    UIAction(title: "USD", state: .on, handler: optionClosureII),
                    UIAction(title: "EUR", state: .on, handler: optionClosureII),
                    UIAction(title: "GBP", state: .on, handler: optionClosureII),
                    UIAction(title: "CHF", state: .on, handler: optionClosureII),
                    UIAction(title: "CNY", state: .on, handler: optionClosureII),
                    UIAction(title: "JPY", state: .on, handler: optionClosureII)
                    
        ])
        
      adjustmentPopUp(button: popUpButtonI)
      adjustmentPopUp(button: popUpButtonII)
        
    }
    
    func stopSkeleton(delay: Double) {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            
            self.lineChart.stopSkeletonAnimation()
            self.lineChart.hideSkeleton()
            self.activityIndicator.stopAnimating()
            self.activityIndicator.hidesWhenStopped = true
            
        }
        
    }
    
    
    func adjustmentPopUp(button : UIButton) {
        
        button.layer.cornerRadius = 5
        button.showsMenuAsPrimaryAction = true
        button.changesSelectionAsPrimaryAction = true

    }
    
    func defaultHistoricalDates() {
            
            for date in Date.dates(from: Date().dateFinder(year: 0, month: 0, day: -7), to: Date()) {
                    
                    OCClient.historical(date: dateFormatter.string(from: date), base: "AED") { data, error in
                        
                        if let data = data {
                            
                            self.lineChart.animate(xAxisDuration: 1)
                            
                            self.setLineChartData()
                            
                            self.entries.append(ChartDataEntry(x: Double(data.timestamp), y: data.rates.usd))
                            
                            self.currencyLabel.text = "1 AED = \(data.rates.usd) USD"
                                                            
                            }

                        }

                    }
            
                }
    
    func setLineChartData() {
        
        let set = LineChartDataSet(entries: self.entries)
        set.colors = ChartColorTemplates.joyful()
        set.circleColors = [.darkGray]
        set.drawHorizontalHighlightIndicatorEnabled = false
        set.highlightColor = .link
        set.drawCirclesEnabled = false
        set.lineWidth = 2

        let lineData = LineChartData(dataSet: set)
        self.lineChart.data = lineData

        self.entries = self.entries.sorted(by: {$0.x < $1.x})
        
        self.highLabel.text = "High  \(lineData.yMax)"
        self.lowLabel.text = "Low  \(lineData.yMin)"
        let doubleString = (lineData.yMax + lineData.yMin) / 2
        self.averageLabel.text = "Average" + "  " + String(format: "%.6f", doubleString)
        
    }
    
    func setStackPosition() {
    
        let modelName = UIDevice.modelName
        
        switch modelName {
            
        case "iPod touch (6th generation)" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPod touch (7th generation)" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 4" :
            constant(stackViewCenterY: -150, stackViewBottom: -2)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 4s" :
            constant(stackViewCenterY: -150, stackViewBottom: -2)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 5" :
            constant(stackViewCenterY: -175, stackViewBottom: -5)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 5c" :
            constant(stackViewCenterY: -175, stackViewBottom: -5)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 5s" :
            constant(stackViewCenterY: -175, stackViewBottom: -5)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 6" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 6 Plus" :
            constant(stackViewCenterY: -240, stackViewBottom: -20)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 6s" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 6s Plus" :
            constant(stackViewCenterY: -240, stackViewBottom: -20)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 7" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 7 Plus" :
            constant(stackViewCenterY: -240, stackViewBottom: -20)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 8" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone 8 Plus" :
            constant(stackViewCenterY: -240, stackViewBottom: -20)
            lineChart.topToSuperview(offset: 190)
        case "iPhone X" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone XS" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone XS Max" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone XR" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone 11" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 11 Pro" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 11 Pro Max" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone 12 mini" :
            constant(stackViewCenterY: -240, stackViewBottom: -40)
        case "iPhone 12" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 12 Pro" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 12 Pro Max" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone 13 mini" :
            constant(stackViewCenterY: -240, stackViewBottom: -40)
        case "iPhone 13" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 13 Pro" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 13 Pro Max" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone 14" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 14 Plus" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 14 Pro" :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
        case "iPhone 14 Pro Max" :
            constant(stackViewCenterY: -280, stackViewBottom: -50)
        case "iPhone SE" :
            constant(stackViewCenterY: -175, stackViewBottom: -5)
            lineChart.topToSuperview(offset: 190)
        case "iPhone SE (2nd generation)" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPhone SE (3rd generation)" :
            constant(stackViewCenterY: -200, stackViewBottom: -10)
            lineChart.topToSuperview(offset: 190)
        case "iPad 2" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (3rd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (4th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (5th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (6th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (7th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (8th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (9th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad (10th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Air" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Air 2" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Air (3rd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Air (4th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Air (5th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini 2" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini 3" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini 4" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini (5th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad mini (6th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (9.7-inch)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (10.5-inch)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (11-inch) (1st generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (11-inch) (2nd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (11-inch) (3rd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (11-inch) (4th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (1st generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (2nd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (3rd generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (4th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (5th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case "iPad Pro (12.9-inch) (6th generation)" :
            constant(stackViewCenterY: -230, stackViewBottom: -30)
        case UIDevice.modelName  :
            constant(stackViewCenterY: -250, stackViewBottom: -50)
            
        default: constant(stackViewCenterY: -250, stackViewBottom: -50)
            
        }
    }
    
    func constant(stackViewCenterY: CGFloat, stackViewBottom: CGFloat) {
        
        for constraint in view.constraints {
            
            switch constraint.identifier {
            case "stackViewCenterY" : constraint.constant = stackViewCenterY
            case "stackViewBottom" : constraint.constant = stackViewBottom
            default : break
                
            }
        }
    }
}

extension Date {
    
    static func dates(from fromDate: Date, to toDate: Date) -> [Date] {
        
        var dates: [Date] = []
        var date = fromDate
        
        while date <= toDate {
            dates.append(date)
            guard let newDate = Calendar.current.date(byAdding: .day, value: 1, to: date) else { break }
            date = newDate
        }
        
        return dates
        
    }
    
    func dateFinder(year: Int, month: Int, day: Int) -> Date {
        
        return Calendar.current.date(byAdding: DateComponents(year: year, month: month, day: day ), to: Date())!
        
    }
}
