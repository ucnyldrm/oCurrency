//
//  CurrencyListViewCell.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 13.06.23.
//

import UIKit

class CurrencyListViewCell: UITableViewCell {
    
    @IBOutlet weak var flagImage: UIImageView!
    @IBOutlet weak var currencyAbridgment: UILabel!
    @IBOutlet weak var currencyName: UILabel!
    
    let abridgments : [String : String] = ["LYD" : "libya", "BYN" : "belarus", "GTQ" : "guatemala", "BTC" : "bitcoin", "BRL" : "brazil", "USD" : "usa", "BZD" : "belize", "LVL" : "latvia", "CHF" : "switzerland", "SLE" : "sierraleone", "XPF" : "frenchpolynesia", "AZN" : "azerbaijan", "JPY" : "japan", "UGX" : "uganda", "MWK" : "malawi", "GNF" : "guinea", "ETB" : "ethiopia", "KES" : "kenya", "CVE" : "capeverde", "XDR" : "imf", "SLL" : "sierraleone", "LKR" : "srilanka", "AFN" : "afghanistan", "CUC" : "cuba", "FJD" : "fiji", "BYR" : "belarus", "VUV" : "vanuatu" , "MGA" : "madagascar", "BWP" : "botswana", "BAM" : "bosnia", "JEP" : "jersey", "GYD" : "guyana", "NAD" : "namibia", "ISK": "iceland", "VND" : "vietnam", "KZT" : "kazakhstan", "ZMW" : "zambia", "PHP" : "philippines", "GEL" : "georgia", "IMP" : "isleofman", "BDT" : "bangladesh", "MRO" : "mauritania", "CAD": "canada", "TJS" : "tajikistan", "QAR" : "qatar", "MMK" : "myanmar", "NOK" : "norway", "JOD" : "jordan", "XAF" : "centralafricanrepublic", "CNY" : "china", "DJF" : "djibouti", "AED" : "emirates", "GGP" : "guernsey", "CLF" : "chile", "BHD" : "bahrain", "XAG" : "silver", "NIO" : "nicaragua", "TTD" : "trinidadandtobago", "KRW" : "south korea", "VEF" : "venezuela", "LSL" : "lesotho", "CDF" : "congo", "DOP" : "dominicanrepublic", "XAU" : "gold", "BGN" : "bulgaria", "MVR": "maldives", "TND" : "tunisia", "AWG" : "aruba", "ILS" : "israel", "MDL" : "moldova", "SYP" : "syria", "SGD" : "singapore", "PEN" : "peru", "HUF" : "hungary", "UZS" : "uzbekistan", "SAR" : "arabia", "TRY" : "turkiye", "IDR" : "indonesia", "AOA" : "angola", "MKD" : "macedonia", "MNT" :"mongolia", "PGK" : "papuanewguinea", "IQD" : "iraq", "BSD" : "bahamas", "PKR" :"pakistan", "MZN" : "mozambique", "SBD" : "solomonislands", "TMT": "turkmenistan", "KMF" : "comoros", "JMD" : "jamaica", "PAB" : "panama", "DZD" : "algeria", "GMD" : "gambia", "PYG" : "paraguay", "SCR" : "seychelles", "CRC" : "costarica", "ARS" : "argentina", "EUR" : "europe", "LRD" : "liberia", "HNL" : "honduras", "XCD" : "caribbean", "SZL" : "swaziland", "OMR" : "oman", "HRK" : "croatia", "FKP" : "falklandislands", "VES" : "venezuela", "CUP" : "cuba", "BMD" : "bermuda", "EGP" : "egypt", "ZAR" : "southafrica", "GHS" : "ghana", "LAK" : "laos", "NPR" : "nepal", "ERN" : "eritrea", "MAD" : "morocco", "UYU" : "uruguay", "KPW" : "northkorea", "SHP" : "sthelena", "KHR" : "cambodia", "NGN" : "nigeria", "YER" : "yemen", "LBP" : "lebanon", "GBP" : "england", "SOS" : "somalia", "HTG" : "haiti", "TZS" : "tanzania", "COP" : "colombia", "UAH" : "ukraine", "NZD" : "newzealand", "ANG" : "curacao", "INR" : "india", "DKK" : "denmark", "BIF" : "burundi", "SEK" : "sweden", "RSD" : "serbia", "SDG" : "sudan", "ZMK" : "zambia", "CLP" : "chile", "ZWL" : "zimbabwe", "THB" : "thailand", "RON" : "romania", "MYR" : "malaysian", "BBD" : "barbados", "RWF" : "rwanda", "AUD" : "australia", "LTL" : "lithuania", "WST" : "samoa", "KGS" : "kyrgyzstan", "TOP" : "tonga", "BOB" : "bolivia", "GIP" : "gibraltar", "AMD" : "armenia", "TWD" : "taiwan", "IRR" : "iran", "SRD" : "suriname", "BND" : "brunei", "KYD" : "caymanislands", "MUR" : "mauritius", "MOP" : "macau", "RUB" : "russia", "SVC" : "elsalvador", "HKD" : "hongkong", "XOF" : "senegal", "STD" : "saotome", "BTN" : "bhutan", "CZK" : "czechia", "PLN" : "poland", "ALL" : "albania", "MXN" : "mexico", "KWD" : "kuwait"]
    
}

