//
//  CurrencyViewController.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 16.03.2023.
//

import UIKit
import CoreData

class CurrencyViewController: UIViewController {
    
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var currencyLogo : UIImageView!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var arrowImage: UIImageView!
    @IBOutlet weak var lastUpdateLabel: UILabel!
    @IBOutlet weak var activityIndicator : UIActivityIndicatorView!
    
    var number = String()
    var resultNumber = String()
    var indexPathDidSelectRowAt = IndexPath()
    var indexPathCellForRowAt = [IndexPath]()
    var checkmarks = [Checkmark]()
    var countLabelWidth = CGFloat()
    var selectedCell : Set<IndexPath> = []
    
    var dataController : DataController! {
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.dataController
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityIndicator.startAnimating()

        deviceRowHeight(phone: 75, pad: 90, tableview: self.tableView)
        setLabel()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        resultNumber = ""
        number = ""
        fetchData()
        tableView.reloadData()

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        digitIsHidden(isHidden: true)
        pushViewController()

    }
    
    @IBAction func clearAllTapped(_ sender: UILongPressGestureRecognizer) {
       
        let currencyTVC = typeCasting(indexPath: indexPathDidSelectRowAt)
        currencyTVC.currencyDigit.text?.removeAll()
        currencyTVC.smallDigit.text?.removeAll()
        digitIsHidden(isHidden: true)
        number.removeAll()
        	
    }
    
    @IBAction func buttonsTapped(_ sender: UIButton) {
        
        let currencyTVC = typeCasting(indexPath: indexPathDidSelectRowAt)
        currencyTVC.currencyDigit.textColor = .label
    
        if sender.tag == 14 && number.contains(".") {
            
            number = String(number.prefix(7))
            
            } else {
                      
            number = String(number.prefix(15))

        }
        
        func calculate(value: String)  {

            number += value

            if value.contains(where: {$0.isNumber}) && validInput() {
                
                let expression = NSExpression(format: String(number))
                let result = expression.expressionValue(with: nil, context: nil)
                let x = (result as! NSNumber).doubleValue
                let resultString = formatResult(result: (x))
                if resultString.count < 18 {

                    resultNumber = resultString
                    currencyTVC.currencyDigit.text = formatting(resultString)
                    currencyTVC.smallDigit.text = number.replacingOccurrences(of: "*", with: "x").replacingOccurrences(of: "/", with: "÷")
                    
                } else {
                    
                    number = resultString
                    return
                    
                }
 
            } else if value.contains(where: {$0 == "+" || $0 == "-" || $0 == "*" || $0 == "/"})  {

                currencyTVC.smallDigit.text = number.replacingOccurrences(of: "*", with: "x").replacingOccurrences(of: "/", with: "÷")

            }
                        
        }
        
        switch sender.tag {
            
        case 0 : calculate(value: "0")
        case 1 : calculate(value: "1")
        case 2 : calculate(value: "2")
        case 3 : calculate(value: "3")
        case 4 : calculate(value: "4")
        case 5 : calculate(value: "5")
        case 6 : calculate(value: "6")
        case 7 : calculate(value: "7")
        case 8 : calculate(value: "8")
        case 9 : calculate(value: "9")
        case 10 : guard number.first != nil else {return}
            
            if validInput() {
            calculate(value: "+")
            digitIsHidden(isHidden: false)
        }
       
        case 11 : guard number.first != nil else {return}
            
            if validInput() {
            calculate(value: "-")
            digitIsHidden(isHidden: false)
        }
        
        case 12 : guard number.first != nil else {return}

            if validInput() {
            calculate(value: "*")
            digitIsHidden(isHidden: false)
        }
        
        case 13 : guard number.first != nil else {return}

            if validInput() {
            
            if !number.contains(".") {
                calculate(value: ".")
            }
            
        }

        case 14 :
            
            if !number.isEmpty {
                number.removeLast()
            }
            
            if !number.isEmpty && validInput() {
            
            let expression = NSExpression(format: number)
            let result = expression.expressionValue(with: nil, context: nil) as! Double
            let resultString = formatResult(result: result)
                   
            if resultString.count < 18 {
                                
                resultNumber = resultString
                currencyTVC.currencyDigit.text = formatting(resultString)
                currencyTVC.smallDigit.text = number.replacingOccurrences(of: "*", with: "x").replacingOccurrences(of: "/", with: "÷")
            
            }
            
        } else if !validInput() {
            
            currencyTVC.smallDigit.text = number.replacingOccurrences(of: "*", with: "x").replacingOccurrences(of: "/", with: "÷")
            number.removeLast()
          
            if !resultNumber.isEmpty {
                resultNumber.removeLast()
            }
        
        } else if number.isEmpty {
            
            currencyTVC.currencyDigit.text = ""
            currencyTVC.smallDigit.text = ""
            digitIsHidden(isHidden: true)
        }
        
        case 15 : guard number.first != nil else {return}

            if validInput() {
            calculate(value: "/")
            digitIsHidden(isHidden: false)
        }

        default: return
            
        }
        
        let abridgments = checkmarks.compactMap({$0.abridgments})
    
            for index in indexPathCellForRowAt {
                
                let currencyTVCcellForRowAt = typeCasting(indexPath: index)
                
                func convertCurrency(from: String, to: String, amount: String) {
                    
                    OCClient.convert(from: from, to: to, amount: Double(amount) ?? -1) { data, error in
                        guard let data = data else {return}
                        currencyTVCcellForRowAt.currencyDigit.text = String(data.result.formatted())
                        currencyTVCcellForRowAt.currencyDigit.textColor = .label
                    }
                }
                
                if index.row >= abridgments.startIndex && index.row < abridgments.endIndex && indexPathDidSelectRowAt.row >= abridgments.startIndex && indexPathDidSelectRowAt.row < abridgments.endIndex {

                    switch index {
                        
                    case IndexPath(row: 0, section: 0) :
                        convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[0], amount: resultNumber)
                    case IndexPath(row: 1, section: 0) :
                    convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[1], amount: resultNumber)

                    case IndexPath(row: 2, section: 0) :
                    convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[2], amount: resultNumber)

                    case IndexPath(row: 3, section: 0) :
                    convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[3], amount: resultNumber)

                    case IndexPath(row: 4, section: 0) :
                    convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[4], amount: resultNumber)
                    
                    default:
                        return
                    }
                }
            }
        }
    
    func pushViewController () {
                
        let currencyLVC = storyboard?.instantiateViewController(identifier: "currencyListViewController")
        
        if selectedCell.count <= 4 {
            
            if let subviews = currencyLVC?.view.subviews {
                
                for subview in subviews {
                        let myConstraint = subview.constraintWith(identifier: "countLableWidth")
                        myConstraint?.constant = countLabelWidth
                }
            }
            
            currencyLVC?.isModalInPresentation = true
            currencyLVC?.modalPresentationStyle = .pageSheet
            navigationController?.pushViewController(currencyLVC!, animated: true)
            present(currencyLVC!, animated: true)
            
        } else {
            
            currencyLVC?.dismiss(animated: true)
        }
        
    }
    
    func setLabel() {
        
        self.infoLabel.isHidden = true
        self.arrowImage.isHidden = true
        
        let _ = Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { (timer) in
            
            self.infoLabel.fadeOut() { bool in
                
                self.infoLabel.isHidden = false
                self.infoLabel.fadeIn()
                
            }
            self.arrowImage.fadeOut { bool in
                
                self.arrowImage.isHidden = false
                self.arrowImage.fadeIn()
            }
        }
        
        let date = Date()
        let format = date.getFormattedDate(format: "E, d MMM HH:mm:ss")
        
        lastUpdateLabel.text = "Last update : \(format)"
        lastUpdateLabel.isHidden = true
            
              self.currencyLogo.fadeOut() { bool in
                
                self.currencyLogo.fadeIn()
                
                  self.lastUpdateLabel.fadeIn { bool in
                    
                    self.lastUpdateLabel.isHidden = false
                    self.lastUpdateLabel.fadeOut()
            }
        }
    }
    
    func fetchData() {
                
        let fetchedRequest : NSFetchRequest<Checkmark> = Checkmark.fetchRequest()
        
        do {
            
            checkmarks = try dataController.viewContext.fetch(fetchedRequest)
            
            checkmarks = checkmarks.filter({$0.currencies != nil})
            
            for checkmark in checkmarks {
                
                if self.selectedCell.count < 5 {
                    selectedCell.insert([Int(checkmark.section), Int(checkmark.row)])

                }
            }
            
            try dataController.viewContext.save()
            
        } catch {
            
            fatalError("The fetch could not be performed: \(error.localizedDescription)")

        }
        
    }
    
    func formatResult(result : Double) -> String {
        
        if (result.truncatingRemainder(dividingBy: 1) == 0) {
            
            return String(format: "%.0f", result)
       
        } else {
            
            return String(format: "%.5f", result)
        }
    }
    
    func digitIsHidden(isHidden: Bool) {
        
        let currencyTVC = typeCasting(indexPath: indexPathDidSelectRowAt)
        currencyTVC.smallDigit.isHidden = isHidden
        
    }
    
    func validInput() -> Bool {
        
        var count = 0
        var funcCharIndexes = [Int]()
        
        for char in number {
            
            if specialCharacter(char: char) {
                
                funcCharIndexes.append(count)
            }
            
            count += 1
        }
        
        var previous : Int = -1
        
        for index in funcCharIndexes {
            
            if index == 0 {
                
                return false
            }
            
            if index == number.count - 1 {
                
                return false
            }
            
            if previous != -1  {
                
                if index - previous == 1 {
                    
                    return false
                }
            }
            previous = index
        }
        
        return true
    }
    
    func specialCharacter(char: Character) -> Bool {

        switch char {
            
        case "*" : return true
        case "/" : return true
        case "+" : return true
        case "-" : return !number.hasSuffix("-") ? false : true
        case "." : return true
        default : return false
            
        }
    }

    func typeCasting(indexPath : IndexPath) -> CurrencyTableViewCell {
        
        let currencyTVC = tableView.cellForRow(at: indexPath) as! CurrencyTableViewCell
        
        return currencyTVC
        
    }
    
    func formatting(_ value: String?) -> String {
        
        guard value != nil else { return "0.00" }
        
        if let doubleValue = Double(value!) {
            
            let formatter = NumberFormatter()
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = number.contains(".") ? 5 : 0
            formatter.numberStyle = .currencyAccounting
            formatter.currencySymbol = ""
            return formatter.string(from: NSNumber(value: doubleValue)) ?? "\(doubleValue)"
       
        }
        
        return value ?? ""
        
    }
    
    func constant(stackViewHeight: CGFloat, countLableWidth: CGFloat) {
         
         for subview in view.subviews {
             
             let myConstraint = subview.constraintWith(identifier: "stackViewHeight")
             myConstraint?.constant = stackViewHeight
             self.countLabelWidth = countLableWidth
             
         }
        
      }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "currencyListViewController" {

            let currencyLVC = segue.destination as! CurrencyListViewController
     
            if let view = currencyLVC.view {
                            
                for subview in view.subviews {
                    
                    let myConstraint = subview.constraintWith(identifier: "countLableWidth")
                    myConstraint?.constant = countLabelWidth

              }
           }
        }
     }
    
    func setScreenSize() {
        
        let modelName = UIDevice.modelName
        
        switch modelName {
            
        case "iPod touch (6th generation)" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPod touch (7th generation)" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone 4" :
            constant(stackViewHeight: 140, countLableWidth: 10)
        case "iPhone 4s" :
            constant(stackViewHeight: 140, countLableWidth: 10)
        case "iPhone 5" :
            constant(stackViewHeight: 160, countLableWidth: 15)
        case "iPhone 5c" :
            constant(stackViewHeight: 160, countLableWidth: 15)
        case "iPhone 5s" :
            constant(stackViewHeight: 160, countLableWidth: 15)
        case "iPhone 6" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone 6 Plus" :
            constant(stackViewHeight: 205, countLableWidth: 20)
        case "iPhone 6s" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone 6s Plus" :
            constant(stackViewHeight: 205, countLableWidth: 20)
        case "iPhone 7" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone 7 Plus" :
            constant(stackViewHeight: 205, countLableWidth: 20)
        case "iPhone 8" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone 8 Plus" :
            constant(stackViewHeight: 205, countLableWidth: 20)
        case "iPhone X" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone XS" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone XS Max" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone XR" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone 11" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 11 Pro" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 11 Pro Max" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone 12 mini" :
            constant(stackViewHeight: 220, countLableWidth: 20)
        case "iPhone 12" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 12 Pro" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 12 Pro Max" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone 13 mini" :
            constant(stackViewHeight: 220, countLableWidth: 20)
        case "iPhone 13" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 13 Pro" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 13 Pro Max" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone 14" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 14 Plus" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 14 Pro" :
            constant(stackViewHeight: 230, countLableWidth: 30)
        case "iPhone 14 Pro Max" :
            constant(stackViewHeight: 250, countLableWidth: 60)
        case "iPhone SE" :
            constant(stackViewHeight: 160, countLableWidth: 15)
        case "iPhone SE (2nd generation)" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPhone SE (3rd generation)" :
            constant(stackViewHeight: 180, countLableWidth: 20)
        case "iPad 2" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (3rd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (4th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (5th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (6th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (7th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (8th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (9th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad (10th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Air" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Air 2" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Air (3rd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Air (4th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Air (5th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini 2" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini 3" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini 4" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini (5th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad mini (6th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (9.7-inch)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (10.5-inch)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (11-inch) (1st generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (11-inch) (2nd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (11-inch) (3rd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (11-inch) (4th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (1st generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (2nd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (3rd generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (4th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (5th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case "iPad Pro (12.9-inch) (6th generation)" :
            constant(stackViewHeight: 310, countLableWidth: 60)
        case UIDevice.modelName  :
            constant(stackViewHeight: 230, countLableWidth: 30)
            
        default: constant(stackViewHeight: 230, countLableWidth: 30)

        }
    }
}

extension CurrencyViewController : UITableViewDelegate, UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "currencyTableViewCell", for: indexPath) as! CurrencyTableViewCell
        
        self.indexPathCellForRowAt.append(indexPath)
        
        setScreenSize()

            let index = IndexPath(row: 2, section: 0)
            tableView.selectRow(at: index, animated: true, scrollPosition: .none)
            self.indexPathDidSelectRowAt = index
        
        let abridgments = checkmarks.compactMap({$0.abridgments})
        let detailedText = checkmarks.compactMap({$0.currencies})
        
        if indexPath.row >= abridgments.startIndex && indexPath.row < abridgments.endIndex && indexPathDidSelectRowAt.row >= abridgments.startIndex && indexPathDidSelectRowAt.row < abridgments.endIndex {
            
            func convertCurrency(from: String, to: String, amount: String) {
                
                if !Reachability.isConnectedToNetwork() {
                    
                    let alert = UIAlertController(title: "Problem Connecting", message: "Check your internet connection and try again.", preferredStyle: .alert)
                    let action = UIAlertAction(title: "Try again", style: .default) { alert in
                        
                        if Reachability.isConnectedToNetwork() {
                                                        
                            OCClient.convert(from: from, to: to, amount: Double(amount) ?? -1) { data, error in
                                guard let data = data else {return}
                                cell.currencyDigit.text = String(data.result.formatted())
                                cell.currencyDigit.textColor = .gray
                                self.activityIndicator.stopAnimating()
                                self.activityIndicator.hidesWhenStopped = true
                                self.tableView.reloadData()
                                
                            }
                            
                        } else {
                            
                            self.tableView.reloadData()
                            
                        }
                    }
                    
                    alert.addAction(action)
                    self.present(alert, animated: true)
                    
                } else {
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        
                        OCClient.convert(from: from, to: to, amount: Double(amount) ?? -1) { data, error in
                            guard let data = data else {return}
                            cell.currencyDigit.text = String(data.result.formatted())
                            cell.currencyDigit.textColor = .gray
                            self.activityIndicator.stopAnimating()
                            self.activityIndicator.hidesWhenStopped = true
                            
                        }
                        
                    }
             
                }
                
            }
                
            switch indexPath {
            
            case IndexPath(row: 0, section: 0) :
                
                cell.currencyAbridgment.text = abridgments[0]
                cell.currencyDetailedText.text = detailedText[0]
                convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[0], amount: "1")
                
            case IndexPath(row: 1, section: 0) :
                
                cell.currencyAbridgment.text = abridgments[1]
                cell.currencyDetailedText.text = detailedText[1]
                convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[1], amount: "1")
                
            case IndexPath(row: 2, section: 0) :
                
                cell.currencyAbridgment.text = abridgments[2]
                cell.currencyDetailedText.text = detailedText[2]
                cell.currencyDigit.text = "1"
                cell.currencyDigit.textColor = .gray
                convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[2], amount: "1")
                
            case IndexPath(row: 3, section: 0) :
                
                cell.currencyAbridgment.text = abridgments[3]
                cell.currencyDetailedText.text = detailedText[3]
                convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[3], amount: "1")
                
            case IndexPath(row: 4, section: 0) :
                
                cell.currencyAbridgment.text = abridgments[4]
                cell.currencyDetailedText.text = detailedText[4]
                convertCurrency(from: abridgments[tableView.indexPathForSelectedRow!.row], to: abridgments[4], amount: "1")
                
            default : cell.currencyAbridgment.text = ""
                
            }
           
            let currencyLVC = CurrencyListViewCell()
            
            for abridgment in currencyLVC.abridgments {
                
                if abridgments[indexPath.row] == abridgment.key {
                    
                    cell.flagImage.image = UIImage(named: "\(abridgment.value)")
                    
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        self.indexPathDidSelectRowAt = indexPath
        
        if !number.isEmpty {
            number.removeAll()
        }
    
        digitIsHidden(isHidden: true)

    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {

        digitIsHidden(isHidden: true)

    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {

        let action =  UIContextualAction(style: .normal, title: "Switch", handler: { (action,view,completionHandler ) in

                        completionHandler(true)
                    })
        
        let currencyLVC = storyboard?.instantiateViewController(withIdentifier: "currencyListViewController") as! CurrencyListViewController
        

        currencyLVC.modalPresentationStyle = .pageSheet
        
        self.navigationController?.pushViewController(currencyLVC, animated: true)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            
            self.present(currencyLVC, animated: true)

        }

        let abridgments = checkmarks.compactMap({$0.abridgments})
        let key = abridgments[indexPath.row]
        
        let deleteObjects = checkmarks.first(where: {$0.abridgments == key})
        
        if let deleteObjects = deleteObjects {
            
            dataController.viewContext.delete(deleteObjects)
            try? dataController.viewContext.save()
            
        }
     
        for subview in currencyLVC.view.subviews {
            
            let myConstraint = subview.constraintWith(identifier: "countLableWidth")
            myConstraint?.constant = countLabelWidth
            
            
        }
        
                action.image = UIImage(systemName: "arrow.left.arrow.right")
                action.backgroundColor = .systemIndigo
                let configuration = UISwipeActionsConfiguration(actions: [action])
                return configuration

    }

}

extension UIViewController {
    
    func deviceRowHeight(phone: CGFloat, pad: CGFloat, tableview: UITableView) {
        
        let device = UIScreen.main.traitCollection.userInterfaceIdiom
        
        switch device {
            
        case .phone : tableview.rowHeight = phone
        case .pad : tableview.rowHeight = pad
        default : return
            
        }
        
    }
    
}

public extension UIDevice {

    static let modelName: String = {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
  
        func mapToDevice(identifier: String) -> String { // swiftlint:disable:this cyclomatic_complexity
            #if os(iOS)
            switch identifier {
            case "iPod5,1":                                       return "iPod touch (5th generation)"
            case "iPod7,1":                                       return "iPod touch (6th generation)"
            case "iPod9,1":                                       return "iPod touch (7th generation)"
            case "iPhone3,1", "iPhone3,2", "iPhone3,3":           return "iPhone 4"
            case "iPhone4,1":                                     return "iPhone 4s"
            case "iPhone5,1", "iPhone5,2":                        return "iPhone 5"
            case "iPhone5,3", "iPhone5,4":                        return "iPhone 5c"
            case "iPhone6,1", "iPhone6,2":                        return "iPhone 5s"
            case "iPhone7,2":                                     return "iPhone 6"
            case "iPhone7,1":                                     return "iPhone 6 Plus"
            case "iPhone8,1":                                     return "iPhone 6s"
            case "iPhone8,2":                                     return "iPhone 6s Plus"
            case "iPhone9,1", "iPhone9,3":                        return "iPhone 7"
            case "iPhone9,2", "iPhone9,4":                        return "iPhone 7 Plus"
            case "iPhone10,1", "iPhone10,4":                      return "iPhone 8"
            case "iPhone10,2", "iPhone10,5":                      return "iPhone 8 Plus"
            case "iPhone10,3", "iPhone10,6":                      return "iPhone X"
            case "iPhone11,2":                                    return "iPhone XS"
            case "iPhone11,4", "iPhone11,6":                      return "iPhone XS Max"
            case "iPhone11,8":                                    return "iPhone XR"
            case "iPhone12,1":                                    return "iPhone 11"
            case "iPhone12,3":                                    return "iPhone 11 Pro"
            case "iPhone12,5":                                    return "iPhone 11 Pro Max"
            case "iPhone13,1":                                    return "iPhone 12 mini"
            case "iPhone13,2":                                    return "iPhone 12"
            case "iPhone13,3":                                    return "iPhone 12 Pro"
            case "iPhone13,4":                                    return "iPhone 12 Pro Max"
            case "iPhone14,4":                                    return "iPhone 13 mini"
            case "iPhone14,5":                                    return "iPhone 13"
            case "iPhone14,2":                                    return "iPhone 13 Pro"
            case "iPhone14,3":                                    return "iPhone 13 Pro Max"
            case "iPhone14,7":                                    return "iPhone 14"
            case "iPhone14,8":                                    return "iPhone 14 Plus"
            case "iPhone15,2":                                    return "iPhone 14 Pro"
            case "iPhone15,3":                                    return "iPhone 14 Pro Max"
            case "iPhone8,4":                                     return "iPhone SE"
            case "iPhone12,8":                                    return "iPhone SE (2nd generation)"
            case "iPhone14,6":                                    return "iPhone SE (3rd generation)"
            case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":      return "iPad 2"
            case "iPad3,1", "iPad3,2", "iPad3,3":                 return "iPad (3rd generation)"
            case "iPad3,4", "iPad3,5", "iPad3,6":                 return "iPad (4th generation)"
            case "iPad6,11", "iPad6,12":                          return "iPad (5th generation)"
            case "iPad7,5", "iPad7,6":                            return "iPad (6th generation)"
            case "iPad7,11", "iPad7,12":                          return "iPad (7th generation)"
            case "iPad11,6", "iPad11,7":                          return "iPad (8th generation)"
            case "iPad12,1", "iPad12,2":                          return "iPad (9th generation)"
            case "iPad13,18", "iPad13,19":                        return "iPad (10th generation)"
            case "iPad4,1", "iPad4,2", "iPad4,3":                 return "iPad Air"
            case "iPad5,3", "iPad5,4":                            return "iPad Air 2"
            case "iPad11,3", "iPad11,4":                          return "iPad Air (3rd generation)"
            case "iPad13,1", "iPad13,2":                          return "iPad Air (4th generation)"
            case "iPad13,16", "iPad13,17":                        return "iPad Air (5th generation)"
            case "iPad2,5", "iPad2,6", "iPad2,7":                 return "iPad mini"
            case "iPad4,4", "iPad4,5", "iPad4,6":                 return "iPad mini 2"
            case "iPad4,7", "iPad4,8", "iPad4,9":                 return "iPad mini 3"
            case "iPad5,1", "iPad5,2":                            return "iPad mini 4"
            case "iPad11,1", "iPad11,2":                          return "iPad mini (5th generation)"
            case "iPad14,1", "iPad14,2":                          return "iPad mini (6th generation)"
            case "iPad6,3", "iPad6,4":                            return "iPad Pro (9.7-inch)"
            case "iPad7,3", "iPad7,4":                            return "iPad Pro (10.5-inch)"
            case "iPad8,1", "iPad8,2", "iPad8,3", "iPad8,4":      return "iPad Pro (11-inch) (1st generation)"
            case "iPad8,9", "iPad8,10":                           return "iPad Pro (11-inch) (2nd generation)"
            case "iPad13,4", "iPad13,5", "iPad13,6", "iPad13,7":  return "iPad Pro (11-inch) (3rd generation)"
            case "iPad14,3", "iPad14,4":                          return "iPad Pro (11-inch) (4th generation)"
            case "iPad6,7", "iPad6,8":                            return "iPad Pro (12.9-inch) (1st generation)"
            case "iPad7,1", "iPad7,2":                            return "iPad Pro (12.9-inch) (2nd generation)"
            case "iPad8,5", "iPad8,6", "iPad8,7", "iPad8,8":      return "iPad Pro (12.9-inch) (3rd generation)"
            case "iPad8,11", "iPad8,12":                          return "iPad Pro (12.9-inch) (4th generation)"
            case "iPad13,8", "iPad13,9", "iPad13,10", "iPad13,11":return "iPad Pro (12.9-inch) (5th generation)"
            case "iPad14,5", "iPad14,6":                          return "iPad Pro (12.9-inch) (6th generation)"
            case "AppleTV5,3":                                    return "Apple TV"
            case "AppleTV6,2":                                    return "Apple TV 4K"
            case "AudioAccessory1,1":                             return "HomePod"
            case "AudioAccessory5,1":                             return "HomePod mini"
            case "i386", "x86_64", "arm64":                       return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "iOS"))"
            default:                                              return identifier
            }
            #elseif os(tvOS)
            switch identifier {
            case "AppleTV5,3": return "Apple TV 4"
            case "AppleTV6,2": return "Apple TV 4K"
            case "i386", "x86_64": return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "tvOS"))"
            default: return identifier
            }
            #endif
        }

        return mapToDevice(identifier: identifier)
    }()

}

extension UIView{
    
    func constraintWith(identifier: String) -> NSLayoutConstraint?{
        return self.constraints.first(where: {$0.identifier == identifier})
    }
    
    func fadeIn(duration: TimeInterval = 2.0, delay: TimeInterval = 2.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.alpha = 1.0
            }, completion: completion)  }

    func fadeOut(duration: TimeInterval = 2.0, delay: TimeInterval = 2.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in}) {
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.curveEaseIn, animations: {
            self.alpha = 0.0
            }, completion: completion)
    }
    
}

extension Date {
   func getFormattedDate(format: String) -> String {
        let dateformat = DateFormatter()
        dateformat.dateFormat = format
        return dateformat.string(from: self)
    }
}
