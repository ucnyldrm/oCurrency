//
//  CurrencyListViewController.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 7.06.23.
//

import UIKit
import CoreData

class CurrencyListViewController: UIViewController, NSFetchedResultsControllerDelegate {
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var smallFlagImageI: UIImageView!
    @IBOutlet weak var smallFlagImageII: UIImageView!
    @IBOutlet weak var smallFlagImageIII: UIImageView!
    @IBOutlet weak var smallFlagImageIV: UIImageView!
    @IBOutlet weak var smallFlagImageV: UIImageView!
    @IBOutlet weak var smallAbridgementI: UILabel!
    @IBOutlet weak var smallAbridgementII: UILabel!
    @IBOutlet weak var smallAbridgementIII: UILabel!
    @IBOutlet weak var smallAbridgementIV: UILabel!
    @IBOutlet weak var smallAbridgementV: UILabel!
    
    var indexPath = IndexPath()
    var currency : [String : [String : String]] = [:]
    var selectedCell : Set<IndexPath> = []
    var checkmarks = [Checkmark]()
    var searching = false
    var namesAndabridgments = [String : String]()
    var filteredNamesAndAbridgments = [String : String]()
    let fetchedRequest : NSFetchRequest<Checkmark> = Checkmark.fetchRequest()

    var dataController : DataController! {
        
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.dataController
        
    }
    
    struct Group {
        
        let title : String
        let currencies : [String : String]
        
    }
    
    var models = [Group]()
    
    let alphabet : [String] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]


    override func viewDidLoad() {
        super.viewDidLoad()
        
        OCClient.symbols(completion: handleSymbols(symbol:error:))
        fetchData()
        deviceRowHeight(phone: 70, pad: 90, tableview: self.tableView)
        self.isModalInPresentation = true

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if modalPresentationStyle == .pageSheet {
            presentingViewController?.beginAppearanceTransition(false, animated: animated)
        }
    
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if modalPresentationStyle == .pageSheet {
            presentingViewController?.endAppearanceTransition()
        }
        
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        if modalPresentationStyle == .pageSheet {
            presentingViewController?.beginAppearanceTransition(true, animated: animated)
        }
  
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        if modalPresentationStyle == .pageSheet {
            presentingViewController?.endAppearanceTransition()
        }
    
    }

    func fetchData() {
        
        do {
                              
                checkmarks = try dataController.viewContext.fetch(fetchedRequest)
            
                checkmarks = checkmarks.filter({$0.currencies != nil})
            
            for checkmark in checkmarks {
                
                if selectedCell.count < 5 {
                    
                    selectedCell.insert([Int(checkmark.section), Int(checkmark.row)])

                }
            
                checkmark.count = Int16(self.selectedCell.count)
                try? dataController.viewContext.save()
                self.countLabel.text = checkmark.count == 0 ? "" : String(checkmark.count)
            }
            
        } catch {
            
            fatalError("The fetch could not be performed: \(error.localizedDescription)")

        }
        
    }
    
    func setUpData() {

        for (key,value) in currency {
            
            let title = models.compactMap({$0.title})
            
            if !title.contains(key) {
                
                models.append(Group(title: key, currencies: value))
        
            }
            
        }
    
        models = models.sorted(by: {$0.title < $1.title})
        
        for model in models {
            
            filteredNamesAndAbridgments = model.currencies.merging(filteredNamesAndAbridgments, uniquingKeysWith: {(first, _) in first })
            
        }

    }

    func handleSymbols(symbol : SymbolResponse?, error: Error?) {
        
        guard let symbol = symbol else {return}
        
        let symbolSorted = symbol.symbols.sorted(by: {$0 < $1})
        
        for (key, _) in symbolSorted {
            
            func updateData(char: String) {
                
                if key.hasPrefix(char) {
                    
                    currency.updateValue(symbol.symbols.filter({$0.key.hasPrefix(char)}), forKey: char)
              
                }
            }
    
            for abc in alphabet {
                
                updateData(char: abc)
        
            }
        }
        
        setUpData()
        
        self.tableView.reloadData()
        
    }
}

extension CurrencyListViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return namesAndabridgments.count
        }
        
        return models[section].currencies.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if searching {
            return 1
        }
        
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "currencyListViewCell", for: indexPath) as! CurrencyListViewCell
        
        self.indexPath = indexPath
        
        var data = models[indexPath.section].currencies.compactMap({$0})
        var searchData = namesAndabridgments.compactMap({$0})
        
        data = data.sorted(by: {$0.key < $1.key})
        searchData = searchData.sorted(by: {$0.key < $1.key})

        if searching {
            
            let (key, value) = searchData[indexPath.row]

            cell.currencyName.text = value
            cell.currencyAbridgment.text = key

            for abridgment in cell.abridgments {
                
                if key == abridgment.key {
                    
                    cell.flagImage.image = UIImage(named: "\(abridgment.value)")

                }
            }

        } else {
        
        let (key, value) = data[indexPath.row]
        cell.currencyName.text = value
        cell.currencyAbridgment.text = key

        let abridgments = checkmarks.compactMap({$0.abridgments})

            for abridgment in cell.abridgments {
            
                if key == abridgment.key {
            
                    cell.flagImage.image = UIImage(named: "\(abridgment.value)")
                }
                
                if !abridgments.isEmpty && abridgments.count == 5 {
                    
                    if abridgments[0] == abridgment.key {
                        smallAbridgementI.text = abridgments[0]
                        smallFlagImageI.image = UIImage(named: "\(abridgment.value)")
                    } else if abridgments[1] == abridgment.key {
                        smallAbridgementII.text = abridgments[1]
                        smallFlagImageII.image = UIImage(named: "\(abridgment.value)")
                    } else if abridgments[2] == abridgment.key {
                        smallAbridgementIII.text = abridgments[2]
                        smallFlagImageIII.image = UIImage(named: "\(abridgment.value)")
                    } else if abridgments[3] == abridgment.key {
                        smallAbridgementIV.text = abridgments[3]
                        smallFlagImageIV.image = UIImage(named: "\(abridgment.value)")
                    } else if abridgments[4] == abridgment.key {
                        smallAbridgementV.text = abridgments[4]
                        smallFlagImageV.image = UIImage(named: "\(abridgment.value)")
                    }
                }
            }
        }
        
        if searching {
            
            let (_ ,value) = searchData[indexPath.row]
            
            cell.accessoryType = checkmarks.contains(where: {$0.currencies == value}) ? .checkmark : .none
        } else {
            cell.accessoryType = selectedCell.contains(indexPath) ? .checkmark : .none

        }
    
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "currencyListViewCell", for: indexPath) as! CurrencyListViewCell
                
            if selectedCell.filter({$0 != indexPath}).count == 4 {
                
                self.dismiss(animated: true)
           
            }
        
        var data = models[indexPath.section].currencies.compactMap({$0})
        data = data.sorted(by: {$0.key < $1.key})
        
        var searchData = namesAndabridgments.compactMap({$0})
        searchData = searchData.sorted(by: {$0.key < $1.key})
        
        var (key, value) = (String(), String())
    
        if searching {
            
            (key, value) = searchData[indexPath.row]

        } else {
            
            (key, value) = data[indexPath.row]
        }



        let checkmark = Checkmark(context: dataController.viewContext)
        
        if selectedCell.contains(indexPath) {

            selectedCell.remove(indexPath)
            
            let deleteObject = checkmarks.first(where: {$0.row == indexPath.row})
            
            if let deleteObject = deleteObject {
            
                dataController.viewContext.delete(deleteObject)
                try? dataController.viewContext.save()

            }

                if smallAbridgementI.text == key {
                    smallAbridgementI.text = ""
                    smallFlagImageI.image = nil
                }
                
                if smallAbridgementII.text == key {
                    smallAbridgementII.text = ""
                    smallFlagImageII.image = nil
                }
                
                if smallAbridgementIII.text == key {
                    smallAbridgementIII.text = ""
                    smallFlagImageIII.image = nil
                }
                
                if smallAbridgementIV.text == key {
                    smallAbridgementIV.text = ""
                    smallFlagImageIV.image = nil
                }
                
                if smallAbridgementV.text == key {
                    smallAbridgementV.text = ""
                    smallFlagImageV.image = nil
                }
                        
        
        } else if selectedCell.count < 5 {
            
                selectedCell.insert(indexPath)
       
                checkmark.section = Int16(indexPath.section)
                checkmark.row = Int16(indexPath.row)
                checkmark.abridgments = key
                checkmark.currencies = value
                try? dataController.viewContext.save()

             
            for abridgment in cell.abridgments {
                
                if key == abridgment.key {
                    
                    var arraySelectedCell = Array(selectedCell)
                    arraySelectedCell = arraySelectedCell.sorted()
                    
                    if arraySelectedCell.endIndex == 1 {
                        
                        smallFlagImageI.image = UIImage(named: abridgment.value)
                        smallAbridgementI.text = key
                        
                    } else if arraySelectedCell.endIndex == 2 {
                        
                        self.smallFlagImageII.image = UIImage(named: abridgment.value)
                        self.smallAbridgementII.text = key
                        
                    } else if arraySelectedCell.endIndex == 3 {
                        
                        self.smallFlagImageIII.image = UIImage(named: abridgment.value)
                        self.smallAbridgementIII.text = key
                        
                    } else if arraySelectedCell.endIndex == 4 {
                        
                        self.smallFlagImageIV.image = UIImage(named: abridgment.value)
                        self.smallAbridgementIV.text = key
                        
                    } else if arraySelectedCell.endIndex == 5 {
                        
                        self.smallFlagImageV.image = UIImage(named: abridgment.value)
                        self.smallAbridgementV.text = key
                        
                    }
                }
            }
        }

        self.countLabel.text = selectedCell.count == 0 ? "" : String(selectedCell.count)
        
        self.tableView.reloadData()

    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        if selectedCell.contains(where: {$0.row == indexPath.row && $0.section == indexPath.section}) {
            return nil
        }
        
        return indexPath
        
    }
  
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {

        if searching {
            return ""
        }
        
        return models[section].title

    }

    func sectionIndexTitles(for tableView: UITableView) -> [String]? {

        if searching {
            return nil
        }

        return alphabet.compactMap({"\($0)"})

    }

    func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        
        guard let targetIndex = models.firstIndex(where: {$0.title == title}) else {

            return 0

        }

        return targetIndex

    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        (view as! UITableViewHeaderFooterView).contentView.backgroundColor = UIColor(named: "lead")
    
        (view as! UITableViewHeaderFooterView).textLabel?.font = .preferredFont(forTextStyle: .headline)

    }

}

extension CurrencyListViewController : UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    namesAndabridgments = filteredNamesAndAbridgments.filter({$0.key.prefix(searchText.count) == searchText || $0.value.prefix(searchText.count) == searchText})
        
        searching = true
        
            if searchText.isEmpty {
                
                searching = false

            }
        
        tableView.reloadData()
        
    }
 
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        searchBar.showsCancelButton = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
        searching = false
        tableView.reloadData()
    }
    
}


