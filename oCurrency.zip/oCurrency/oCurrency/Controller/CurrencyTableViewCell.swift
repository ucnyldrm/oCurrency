//
//  CurrencyTableViewCell.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 5.06.23.
//

import UIKit

class CurrencyTableViewCell: UITableViewCell {

    @IBOutlet weak var currencyAbridgment: UILabel!
    @IBOutlet weak var currencyDetailedText: UILabel!
    @IBOutlet weak var currencyDigit: UILabel!
    @IBOutlet weak var flagImage: UIImageView!
    @IBOutlet weak var smallDigit: UILabel!
    
}

