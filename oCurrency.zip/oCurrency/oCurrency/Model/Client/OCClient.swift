//
//  OCClient.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 28.03.2023.
//

import UIKit

class OCClient {
    
    static let apiKey = "caf4a3767aa20cedfd33ab0f300f7923"
    
    
    enum EndPoints {
        
        static let base = "http://api.exchangeratesapi.io/v1/"
        static let apiKeyParam = "?access_key=\(OCClient.apiKey)"
        
        case symbols
        case convert(String,String,Double)
        case historical(String, String)
        
        var url : URL {
            
            return URL(string: stringValue)!
            
        }
        
        var stringValue : String {
            
            switch self {
            
            case .symbols : return OCClient.EndPoints.base + "symbols" + OCClient.EndPoints.apiKeyParam
            case .convert(let from, let to, let amount) : return OCClient.EndPoints.base + "convert" + OCClient.EndPoints.apiKeyParam + "&from=\(from)" + "&to=\(to)" + "&amount=\(amount)" + "&format=1"
            case .historical(let date, let base) : return OCClient.EndPoints.base + date + OCClient.EndPoints.apiKeyParam + "&base=\(base)"
            
            }
            
        }

    }
    
    class func historical(date: String, base: String, completion : @escaping (HistoricalResponse?, Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.historical(date, base).url, responseType: HistoricalResponse.self) { data, error in
            
            if let data = data {
                
                completion(data, nil)
                
            } else {
                
                completion(nil, error)
                
            }
        
        }
        
    }
    
    
    class func convert(from: String, to: String, amount: Double, completion : @escaping (ConvertResponse?, Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.convert(from, to, amount).url, responseType: ConvertResponse.self) { data, error in
            
            if let data = data {
                
                completion(data, nil)
                
            } else {
                
                completion(nil, error)
            }
            
        }

    }
    
    class func symbols(completion: @escaping (SymbolResponse?, Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.symbols.url , responseType: SymbolResponse.self) { data, error in
            
            if let data = data {
                
                completion(data, nil)
                
            } else {
                
                print("Failed to get currency data")
                completion(nil, error)
                
            }
        
        }
     
    }
    
    class func taskForGetRequest<ResponseType : Decodable> (url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) {
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard let data = data else {
                
                DispatchQueue.main.sync {
                    completion(nil, error)
                }
                return
            }
            
            let decoder = JSONDecoder()
            
            do {
                
                let response = try decoder.decode(ResponseType.self, from: data)
                
                DispatchQueue.main.sync {
                    completion(response, nil)
                }
                
            } catch {
                
                DispatchQueue.main.sync {
                    completion(nil, error)
                }
            }
        }
        
        task.resume()
        
    }
    
}


