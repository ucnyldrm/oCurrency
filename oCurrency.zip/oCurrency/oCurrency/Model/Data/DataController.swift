//
//  DataController.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 19.06.23.
//

import UIKit
import CoreData

class DataController  {
    
    var persistentContainer : NSPersistentContainer
    
    var viewContext : NSManagedObjectContext {
        
        return persistentContainer.viewContext
        
    }
    
    init(modelName: String) {
        
        persistentContainer = NSPersistentContainer(name: modelName)
        
    }
    
    func load(completion: (()-> Void)? = nil) {
        
        persistentContainer.loadPersistentStores { storeDescription, error in
            
            guard error == nil else {
                
                fatalError(error!.localizedDescription)
                
            }
            
            self.persistentContainer.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
            
            completion?()
            
        }
        
    }
 
}
