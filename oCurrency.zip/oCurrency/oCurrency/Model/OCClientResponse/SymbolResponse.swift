//
//  SymbolResponse.swift
//  Currency Converter
//
//  Created by Can Yıldırım on 12.06.23.
//

import Foundation

struct SymbolResponse: Codable {
    
    let success: Bool
    let symbols: [String : String]
    
}
