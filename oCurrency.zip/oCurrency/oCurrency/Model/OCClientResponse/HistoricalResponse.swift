//
//  HistoricalResponse.swift
//  oCurrency
//
//  Created by Can Yıldırım on 28.11.23.
//

import Foundation

struct HistoricalResponse: Codable {
    
    let success, historical: Bool
    let date: String
    let timestamp: Int
    let base: String
    let rates: Rates
    
}

struct Rates: Codable {
    
    let usd, eur, gbp, chf, cny, jpy: Double

    enum CodingKeys: String, CodingKey {
        
        case usd = "USD"
        case eur = "EUR"
        case gbp = "GBP"
        case chf = "CHF"
        case cny = "CNY"
        case jpy = "JPY"
        
    }
}
