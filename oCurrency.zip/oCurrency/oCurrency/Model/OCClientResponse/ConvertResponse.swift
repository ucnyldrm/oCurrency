//
//  ConvertResponse.swift
//  oCurrency
//
//  Created by Can Yıldırım on 17.07.23.
//

import Foundation
    
    struct ConvertResponse: Codable {
        
        let success: Bool
        let query: Query
        let info: Info
        let date: String
        let result: Double
        
    }

    struct Info: Codable {
        
        let timestamp: Int
        let rate: Double
        
    }

    struct Query: Codable {
        
        let from, to: String
        let amount: Double
    
}
